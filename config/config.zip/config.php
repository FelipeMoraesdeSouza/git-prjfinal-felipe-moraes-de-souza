<?php

define("SERVIDOR", "5.254.41.129");
define("BANCO", "fms_agenda");
define("USUARIO", "fms_admin");
define("SENHA", "OEjJ8Na^+_!A");


define('CONTROLLER_PADRAO', 'home');
define('METODO_PADRAO', 'index');
define('NAMESPACE_CONTROLLER', 'app\\controllers\\');

define('URL_BASE', 'http://5.254.41.129/home/fms/projeto1/');
