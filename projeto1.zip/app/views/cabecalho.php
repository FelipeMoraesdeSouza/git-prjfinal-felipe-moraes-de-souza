<header class="topo">
			<div class="conteudo">
				<a href="" class="mobmenu fas fa-bars"></a>
				<a href="index.html" class="logo"><img src="<?php echo URL_BASE ?>/assets/img/logo.png"></a>
				<nav class="menu">
					<ul>
						<li><a href="<?php echo URL_BASE ?>">Home</a></li>
						<!--
						<li><a href="<?php echo URL_BASE."cliente/create" ?>">Novo cadastro</a></li>
						<li><a href="<?php echo URL_BASE."cliente"?>">Lista de clientes</a></li>
						-->
						<li><a href="">Sair</a></li>
					</ul>
				</nav>
			</div>
		</header>