<?php

define("SERVIDOR", "localhost");
define("BANCO", "bdlivro");
define("USUARIO", "root");
define("SENHA", "");


define('CONTROLLER_PADRAO', 'home');
define('METODO_PADRAO', 'index');
define('NAMESPACE_CONTROLLER', 'app\\controllers\\');

define('URL_BASE', 'http://localhost/projeto1/');
